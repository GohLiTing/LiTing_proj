from flask import Flask, render_template, request, jsonify
import pandas as pd
import numpy as np
import joblib
from sklearn.preprocessing import OrdinalEncoder, LabelEncoder
from MyForm import UserEntryForm
import json
import matplotlib
matplotlib.use('Agg')  # Use a non-interactive Matplotlib backend
import matplotlib.pyplot as plt  # Import plt from matplotlib

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your secret key'

# Function to plot feature importances
def plot_feature_importances(importances, features):
    indices = np.argsort(importances)

    fig, ax = plt.subplots(figsize=(10, 6))  # Use fig, ax for better compatibility
    ax.set_title('Feature Importances')
    ax.barh(range(len(indices)), importances[indices], color='#8f63f4', align='center', orientation='horizontal')
    ax.set_yticks(range(len(indices)))
    ax.set_yticklabels(features[indices])
    ax.set_xlabel('Relative Importance')

     

    # Save the plot to a file
    plot_file_path = 'static/feature_importances_plot.png'
    fig.savefig(plot_file_path,bbox_inches = 'tight')
    plt.close(fig)  # Close the figure to prevent interference with subsequent plots

    return plot_file_path


# Load your dataset (make sure to adjust the file path)
df_selected_cleaned_reset = pd.read_csv(r'C:\Users\MYPC\Downloads\Dementia.csv')

# Drop 'memory_complain' from df_selected_cleaned_reset
df_selected_cleaned_reset = df_selected_cleaned_reset.drop('memory_complain', axis=1, errors='ignore')

# Load the trained model
model = joblib.load(r'C:\Users\MYPC\Downloads\random_forest_model.joblib')

# Assuming 'ordinal_encoder' and 'label_encoder' are already fitted on training data
# Create an instance of the ordinal encoder for 'vision' and 'audition'
ordinal_encoder = OrdinalEncoder(categories=[['Sees poorly', 'Sees moderately', 'Sees well'], ['Hears poorly', 'Hears moderately', 'Hears well']])
ordinal_encoder.fit(df_selected_cleaned_reset[['vision', 'audition']])

# Create instances of the label encoder for 'gait_speed_slower', 'grip_strength_abnormal', and 'low_physical_activity'
label_encoder_gait_speed = LabelEncoder()
label_encoder_grip_strength = LabelEncoder()
label_encoder_activity = LabelEncoder()

label_encoder_gait_speed.fit(df_selected_cleaned_reset['gait_speed_slower'])
label_encoder_grip_strength.fit(df_selected_cleaned_reset['grip_strength_abnormal'])
label_encoder_activity.fit(df_selected_cleaned_reset['low_physical_activity'])

# Plot feature importances outside the Flask route
features = df_selected_cleaned_reset.columns
importances = model.feature_importances_
feature_plot = plot_feature_importances(importances, features)



def generate_gauge_data(probabilities):
    print("Probabilities:", probabilities)  # Add this line to check the probabilities received
    if probabilities is not None and len(probabilities) > 0:
        probability_value = probabilities[0]
        print("Probability Value:", probability_value)  # Add this line to check the probability value

        if probability_value > 0.7:
            risk_category = 'High Risk'
        elif probability_value > 0.4:
            risk_category = 'Moderate Risk'
        else:
            risk_category = 'Low Risk'

        gauge_value = probability_value  # Use the probability value as the gauge value

        return {'risk_category': risk_category, 'probability': probability_value, 'gauge': gauge_value}
    else:
        return {'risk_category': 'No Data', 'probability': None, 'gauge': 0.5}  # Set default gauge value when probabilities are not available

@app.route('/')
def index():
    form = UserEntryForm()

    # Assuming you have logic to obtain probabilities
    probabilities = None  # Modify this according to your actual logic

    # Generate gauge data including risk category based on obtained probabilities
    gauge_data = generate_gauge_data(probabilities)

    # Set a dummy value for the gauge chart
    initial_gauge_value = gauge_data['gauge']

    # Get feature importances from the model
    importances = model.feature_importances_

    # Check if importances is not undefined
    if importances is not None:
        importances_json = json.dumps(importances.tolist())
    else:
        # Handle the case where importances is undefined
        importances_json = '[]'  # Default empty JSON array
    # Debugging: Print the value of risk_category
    print("Risk Category:", gauge_data['risk_category'])

    # Pass the risk category along with other variables to the template
    return render_template('index.html', form=form, importances_json=importances_json, probabilities=probabilities, gauge=initial_gauge_value, feature_plot=feature_plot, risk_category=gauge_data['risk_category'])
@app.route('/predict', methods=['POST'])
def predict():
    try:
        content_type = request.headers.get('Content-Type')
        print("Received request with Content-Type:", content_type)

        if content_type == 'application/json':
            # Handle JSON data
            data = request.get_json()
        elif content_type == 'application/x-www-form-urlencoded':
            # Handle form-urlencoded data
            data = request.form.to_dict()
        else:
            print("Invalid Content-Type. Expected JSON or form-urlencoded.")
            return jsonify({'error': 'Invalid content type. Expected JSON or form-urlencoded.'}), 415

        print("Received Data:", data)

        # Create a DataFrame from the input data
        input_df = pd.DataFrame(data, index=[0])

        # Transform 'vision' and 'audition' using the trained ordinal encoder
        input_df[['vision', 'audition']] = ordinal_encoder.transform(input_df[['vision', 'audition']])

        # Convert NaN values to a placeholder (assuming -1 is not used in your encoding)
        input_df = input_df.fillna(-1)

        # Transform 'gait_speed_slower', 'grip_strength_abnormal', and 'low_physical_activity' using the trained label encoder
        input_df['gait_speed_slower'] = label_encoder_gait_speed.transform(input_df['gait_speed_slower'])
        input_df['grip_strength_abnormal'] = label_encoder_grip_strength.transform(input_df['grip_strength_abnormal'])
        input_df['low_physical_activity'] = label_encoder_activity.transform(input_df['low_physical_activity'])

        # Get the missing columns based on the trained model's expectations
        missing_columns = list(set(df_selected_cleaned_reset.columns) - set(input_df.columns))

        # Add missing columns and set their values to -1
        for col in missing_columns:
            input_df[col] = -1

        # Ensure the columns are in the same order as in the trained model
        input_df = input_df[df_selected_cleaned_reset.columns]

        # Check if the number of features in the input matches the model's expectations
        if len(input_df.columns) != model.n_features_in_:
            raise ValueError(f"Number of features in input ({len(input_df.columns)}) does not match the model's expectations ({model.n_features_in_}).")

        # Reshape the input data to match the format expected by the model
        input_data_encoded = input_df.values

        # Perform probability predictions using the loaded model
        probabilities = model.predict_proba(input_data_encoded)[:, 1]

        print("Predicted Probabilities:", probabilities)
        print("Data Type of Probabilities:", type(probabilities))

        if probabilities is None or len(probabilities) == 0:
            probabilities = [0.5]  # Set default probability if probabilities are not available

        # Example logic (you need to modify this based on your requirements)
        gauge_data = generate_gauge_data(probabilities)

        # Print the gauge_data before returning
        print("Gauge Data:", gauge_data)

        # Return the probabilities, gauge data, and feature plot path as JSON
        return jsonify(probabilities=probabilities.tolist(), gauge=gauge_data, risk_category=gauge_data['risk_category'], feature_plot=feature_plot)

    except Exception as e:
        print("Error:", str(e))
        return jsonify({'error': str(e)}), 500


  
if __name__ == '__main__':
    app.run(debug=True)
